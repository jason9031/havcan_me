﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CounterTMT
{
    public class Enum
    {
        public enum AgentStatus
        {
            NONE = -1,
            ONLINE = 0,
            OFFLINE = 1,
            ERROR = 2
        }
    }
}
